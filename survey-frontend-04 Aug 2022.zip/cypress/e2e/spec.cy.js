//from https://docs.cypress.io/guides/end-to-end-testing/writing-your-first-end-to-end-test#Write-your-first-test
describe('My First Test', () => {
    it('Does not do much!', () => {
      expect(true).to.equal(true);
    });
  });