<template>
<div class="container">
    <h3>Thank you for your feedback!!</h3>
</div>
</template>